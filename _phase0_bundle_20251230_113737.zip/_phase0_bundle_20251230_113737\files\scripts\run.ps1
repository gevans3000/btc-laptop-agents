﻿python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt pytest
pip install -e .
pytest -q
la run --agent planner "hello from btc-laptop-agents"
