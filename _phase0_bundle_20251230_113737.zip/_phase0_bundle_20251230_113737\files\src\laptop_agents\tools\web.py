﻿def disabled():
    raise RuntimeError("Web tool is disabled in laptop-only mode. Enable explicitly if desired.")
