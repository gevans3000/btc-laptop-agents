﻿# BTC Laptop Agents — Phase 0 System Map (auto-generated)

## Repo
- Root: C:\Users\lovel\trading\btc-laptop-agents
- Bundle: C:\Users\lovel\trading\btc-laptop-agents\_phase0_bundle_20251230_113737

## How it starts (fill after review)
- Manual command:
- Service/scheduler (Windows Task Scheduler/systemd/launchd):
- Expected run cadence:

## Agents (fill after audit)
- Agent list:
- Triggers:
- Tools used:

## Workflows (fill after audit)
- Data collection:
- Signal generation:
- Paper execution:
- Journal/logging:
- Reporting:

## State & Storage
- DB/SQLite location:
- Journal file(s):
- Cache:

## Observability
- Log location:
- Health checks:
- Alerts:

## Notes
- See info/entrypoint_and_scheduler_hints.txt
